#include <stdio.h>
#include <string.h>

char *ft_strncpy(char *dest, char *src, unsigned int n);

int main()
{
	// Test cases
	char src1[] = "Hello, World!";
	char dest1[20];
	char dest2[20];

	// Using the original strncpy function
	strncpy(dest1, src1, 6);
	dest1[sizeof(dest1) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest1);

	// Using ft_strncpy function
	ft_strncpy(dest2, src1, 6);
	dest2[sizeof(dest2) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest2);

	// More test cases
	char src2[] = "OpenAI";
	char dest3[10];
	char dest4[10];

	// Using the original strncpy function
	strncpy(dest3, src2, sizeof(dest3) - 1);
	dest3[sizeof(dest3) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest3);

	// Using ft_strncpy function
	ft_strncpy(dest4, src2, sizeof(dest4) - 1);
	dest4[sizeof(dest4) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest4);

	// Additional test cases
	char src3[] = "Testing";
	char dest5[15];
	char dest6[15];

	// Using the original strncpy function
	strncpy(dest5, src3, sizeof(dest5) - 1);
	dest5[sizeof(dest5) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest5);

	// Using ft_strncpy function
	ft_strncpy(dest6, src3, sizeof(dest6) - 1);
	dest6[sizeof(dest6) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest6);

	char src4[] = "";
	char dest7[5];
	char dest8[5];

	// Using the original strncpy function
	strncpy(dest7, src4, sizeof(dest7) - 1);
	dest7[sizeof(dest7) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest7);

	// Using ft_strncpy function
	ft_strncpy(dest8, src4, sizeof(dest8) - 1);
	dest8[sizeof(dest8) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest8);

	// More test cases
	char src5[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char dest9[30];
	char dest10[30];

	// Using the original strncpy function
	strncpy(dest9, src5, sizeof(dest9) - 1);
	dest9[sizeof(dest9) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest9);

	// Using ft_strncpy function
	ft_strncpy(dest10, src5, sizeof(dest10) - 1);
	dest10[sizeof(dest10) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest10);

	char src6[] = "0123456789";
	char dest11[15];
	char dest12[15];

	// Using the original strncpy function
	strncpy(dest11, src6, sizeof(dest11) - 1);
	dest11[sizeof(dest11) - 1] = '\0'; // Null-terminate the destination string
	printf("strncpy: \t%s\n", dest11);

	// Using ft_strncpy function
	ft_strncpy(dest12, src6, sizeof(dest12) - 1);
	dest12[sizeof(dest12) - 1] = '\0'; // Null-terminate the destination string
	printf("ft_strncpy: \t%s\n", dest12);



///////// Zero byte test.
	char destf[] = "Epic fail !!!!!";
	char srcf[] = "Success";

	ft_strncpy(destf, srcf, 15);
	printf("ft_strncpy (0byte_test): \t%s\n", destf);

	for (int i = 9; i < 15; i++)
	{
		if (destf[i] != '\0')
			printf("fail");
	}
	return 0;
}
