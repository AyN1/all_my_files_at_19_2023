#include <stdio.h>

int		ft_str_is_printable(char *src);

int		main()
{
	char	c;

	c = 0;
	while (c != 0)
	{
		if ((c < ' ' || c > '~') == ft_str_is_printable(&c))
		{
			printf("Fail for char in decimal: %d\n", (int)c);
			return (0);
		}
		c++;
	}

	printf("Success\n");
}
