
#include <unistd.h>

char	*ft_strlowcase(char *src);

void	ft_putstr(char *str)
{
	int l;

	l = 0;
	while (str[l])
	{
		l++;
	}
	write(1, str, l);
}

int		main()
{
	char c[] = "AbCdEfG-Yz";
	ft_putstr("abcdefg-yz:");
	ft_putstr(ft_strlowcase(c));
	ft_putstr(":");
	ft_putstr(c);
}
